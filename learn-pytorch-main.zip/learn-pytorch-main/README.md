# learn-pytorch
## day1
反向传播

.backward()

.grad

## day2
矩阵与向量计算

## day3
线性回归的实现和简洁实现

## day4
softmax回归的实现和简洁实现

## day5
激活函数

## day6
偏导数

## day7
自定义层
