# learn-java
everyday-learn-java
## day 1
学习Markdown语法

坚持写blog

## day 2
学习dos基本命令

## day 3
基本运算符
位运算符

基本命名原则

## day 4
包机制

doc文档创建
`javadoc`

Scanner输入数据

三种结构

方法

递归

## day 5
数组创建

稀疏数组的压缩与还原

## day 6
对象的创建和引用

封装和继承

super的使用

## day 7
多态

抽象类

接口

内部类

异常的抛出和捕获

## day 8
javaSE总结

## day 9
java 集合
Iterator类
Collection和Map子类

## day 10
ArrayList 类

## day 11
线程基本概念

## day 12
线程2，插队，中断

## day 13
线程3，线程锁

## day 14
注解和反射

## day 15
注解和反射2

## day 16
注解和反射3

## day 17
ArrayList
