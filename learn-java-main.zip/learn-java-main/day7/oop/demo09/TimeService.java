package com.oop.demo09;

public interface TimeService {
    void timer();
}
