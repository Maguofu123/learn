package com.oop.demo08;

//抽象类
public abstract class Action {

    //有人帮我们实现
    //抽象方法，只有方法名字，没有方法实现
    public abstract void doSomething();

}
