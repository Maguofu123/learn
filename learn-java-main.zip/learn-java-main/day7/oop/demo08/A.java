package com.oop.demo08;


//继承，由子类实现方法
//extends：单继承
//接口可以多继承
public class A extends Action{
    @Override
    public void doSomething() {

    }
}
