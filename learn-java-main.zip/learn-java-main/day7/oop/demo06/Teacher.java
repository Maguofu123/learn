package com.oop.demo06;

public class Teacher extends Person{
}
