package com.oop.demo06;

public class Student extends Person{

  public void go(){
      System.out.println("go");
  }


}
