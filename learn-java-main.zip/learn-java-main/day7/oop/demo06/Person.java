package com.oop.demo06;

public class Person {


    public void run(){
        System.out.println("run");

    }

}
