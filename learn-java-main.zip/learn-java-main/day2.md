# day 2
## dos命令
cd切换目录

cd /d切换盘符

cd..退回上一级目录

dir查看当前目录下所有文件

md新建文件夹

rd删除文件夹

cd>a.txt新建文本

del a.txt删除文本

cls清理屏幕

## notepad++编写java程序
定义文件名和类名必须相同

编写完成后使用cmd命令javac name.java 编译成class文件

使用java name.java 运行编译完成的文件

