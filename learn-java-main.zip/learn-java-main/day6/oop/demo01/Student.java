package com.oop.demo01;

//学生类
public class Student {

    //非静态方法
    public void say(){
        System.out.println("学生说话了");
    }
}
