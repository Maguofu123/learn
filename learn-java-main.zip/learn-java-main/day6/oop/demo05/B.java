package com.oop.demo05;

//重写是方法的重写
public class B {

    public void test(){
        System.out.println("B=>test()");
    }
}
