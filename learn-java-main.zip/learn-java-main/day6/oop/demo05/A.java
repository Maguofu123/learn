package com.oop.demo05;

public class A extends B{


    @Override //注解
    public void test() {
        System.out.println("A=>test()");
    }
}
