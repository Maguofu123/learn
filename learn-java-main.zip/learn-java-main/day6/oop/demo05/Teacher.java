package com.oop.demo05;

//老师 子类
public class Teacher extends Person{
}
