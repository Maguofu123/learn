package com.oop.demo03;

public class Pet {

    public String name;
    public int age;

    public void shout(){

        System.out.println("叫了一声");
    }
}
