## day 9
集合
父类Iterator接口
子类Collection接口和Map接口
![image](https://user-images.githubusercontent.com/91414286/189475856-19395f92-c167-4693-8af0-9d7a9471fdde.png)

迭代器
Iterator
`hasNext()`
`next()`
