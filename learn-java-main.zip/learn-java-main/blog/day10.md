## day10
List接口
方法
- .add添加元素
- .add(index, a)指定位置插入元素
- .indexOf搜索元素
- .remove()移除指定位置元素
- .set()替换目标位置元素
- .sublist()返回子集合，前闭后开
