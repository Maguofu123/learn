## day4
包机制

doc文档创建
`javadoc`

Scanner输入数据

三种结构：
sequential structure,
selective structure, 包含if结构和switch结构
cyclic structure，包含while, do while, for循环结构

**关于输出**

默认为println输出后换行，print输出后不换行

\t制表符， \n换行

"" + 连接字符串，并将后面转化为字符串
+ "" 先运算后连接字符串


方法的原子性：即一个方法只实现一个功能

方法调用，值传递

**方法重载**：参数不同即可

cmd执行需要找到包的路径（根目录）

### 递归
*递归头：*
什么时候不调用自身方法，如果没有头，将陷入死循环

*递归体：*
什么时候需要调用自身方法

边界条件，前阶段，返回阶段

**计算器实现**
