package com.learn.method;

public class Demo5 {
    public static void main(String[] args) {
        Demo5 test = new Demo5();
        test.test();


    }
    public void test(){
        test();
    }
}
