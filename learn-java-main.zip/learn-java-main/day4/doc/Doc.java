package com.learn.doc;

/**
 * @author Ma
 * @version 1.0
 * @since 18
 */
public class Doc {
    String name;

    /**
     * @param name
     * @return
     * @throws Exception
     */

    public String test(String name) throws Exception{
        return name;
    }
}
