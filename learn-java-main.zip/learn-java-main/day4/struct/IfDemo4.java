package com.learn.struct;

import java.util.Scanner;

public class IfDemo4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double num = scanner.nextDouble();



        scanner.close();
    }
}
