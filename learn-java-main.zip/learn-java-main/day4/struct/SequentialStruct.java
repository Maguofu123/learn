package com.learn.struct;

public class SequentialStruct {
    public static void main(String[] args) {
        System.out.println("Hello1");
        System.out.println("Hello2");
        System.out.println("Hello3");
    }
}
