package com.learn.struct;

public class WhileDemo2 {
    public static void main(String[] args) {
        //while (true){
            //永远循环
            //等待客户端
            //定时检查
        //}
    }
}
