package com.learn.struct;

public class WhileDemo1 {
    public static void main(String[] args) {
        //输出1-100
        int i = 0;
        while (i < 100){
            i++;
            System.out.println(i);
        }
    }
}
