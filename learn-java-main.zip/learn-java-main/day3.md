## day3
### idea配置环境

empty project- javase 

### 注释
单行注释
`//`

多行注释
`/*
*/`

文档注释
`/**
*/`

一些关键词

![image](https://user-images.githubusercontent.com/91414286/188293984-fac4821d-2255-4649-a852-7c04b5de86e8.png)


### 数据类型
long 在数字后加L
`long num = 20L;`

float 在数字后面加F
`float num = 20F;`

*八大类型*

**基本类型**

int, byte, char, boolean, short, float, long, double

**引用数据类型**

类，接口，数组

### 类型转换
![image](https://user-images.githubusercontent.com/91414286/188294981-79b0eb38-e51a-4b4b-aad8-da0917e1c1c8.png)

### 变量命名规范
![image](https://user-images.githubusercontent.com/91414286/188296006-3cec2cd1-3446-4d0c-b96a-3716e90c71b6.png)

