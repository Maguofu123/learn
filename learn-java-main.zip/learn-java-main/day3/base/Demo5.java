package base;

public class Demo5 {

    //常量 final
    //修饰符，不存在先后顺序
    //static final = final static

    static  final double a = 3.14;
    final static  double b = 2.1;

    public static void main(String[] args) {
        System.out.println(a);
        System.out.println(b);
    }



}
