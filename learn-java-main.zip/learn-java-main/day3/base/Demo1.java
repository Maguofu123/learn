package base;

public class Demo1 {
    public static void main(String[] args) {

        int num1 = 10;
        byte num2 = 22;
        short num3 = 20;
        long num4 = 20L;
        String name = "我";
        System.out.println(name);

    }
}
