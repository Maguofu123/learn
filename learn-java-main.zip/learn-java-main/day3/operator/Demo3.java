package operator;

public class Demo3 {
    public static void main(String[] args) {
        //幂运算 使用Math类
        double a = Math.pow(2, 3);
        System.out.println(a);
    }

}
