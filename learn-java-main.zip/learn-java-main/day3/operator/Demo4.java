package operator;

public class Demo4 {
    public static void main(String[] args) {
        //逻辑运算
        boolean a = true;
        boolean b = false;

        System.out.println(a && b);
        System.out.println(a || b);
        System.out.println(!a);
    }
}
