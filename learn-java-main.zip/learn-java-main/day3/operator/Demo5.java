package operator;

public class Demo5 {
    public static void main(String[] args) {
        //位运算
        /*
        &， |, ^. ~
        <<, >>
         */
        System.out.println(2 << 3);
        System.out.println(Math.pow(2, 4));

    }
}
