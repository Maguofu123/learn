package operator;

public class Demo1 {
    public static void main(String[] args) {
        //二元运算
        //ctrl + D，复制当前行到下一行

        int a = 1;
        int b = 2;
        int c = 3;
        int d = 4;

        System.out.println(a + b);
        System.out.println(a - b);
        System.out.println(a * c);
        System.out.println(a / d); //int类型
        System.out.println(a / (double)d); //成功

    }
}
