package operator;

public class Demo2 {
    public static void main(String[] args) {
        int a = 10;
        int c = 21;

        //取余 % 即模运算
        System.out.println(c % a); // 21 / 10 = 2 ... 1

    }
}
