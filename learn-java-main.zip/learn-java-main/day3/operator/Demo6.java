package operator;

public class Demo6 {
    public static void main(String[] args) {
        //字符串连接符 +， String
        int a = 10;
        int b = 20;

        System.out.println("" + a + b);
        System.out.println(a + b + "");
        //结果不一致


    }
}
